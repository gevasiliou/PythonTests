#!/bin/bash
test=$(echo this is yad about);echo $test
yad --about
exit
