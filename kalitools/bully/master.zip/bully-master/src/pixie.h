//fixed size
char pixie_pke[1000];					/* save pke */
char pixie_pkr[1000];					/* save pkr */
char pixie_enonce[100];					/* save e-nonce */
char pixie_rnonce[100];					/* save r-nonce */
char pixie_authkey[100];				/* save AuthKey */
char pixie_ehash1[100];					/* save e-hash1 */
char pixie_ehash2[100];					/* save e-hash2 */
	
char p_iface[20];
char p_bssid[256];

int run_pixiewps;
int op_gen_pin;
int debug_level;
