#!/bin/bash
java -Xmx256M -jar DirBuster-1.0-RC1.jar

